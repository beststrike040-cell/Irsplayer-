package com.example.cpuvideoplayer

import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.TextureView
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ImageView
import android.widget.Spinner
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer

class MainActivity : AppCompatActivity() {

    private lateinit var player: ExoPlayer
    private lateinit var textureView: TextureView
    private lateinit var overlayImage: ImageView
    private lateinit var statusText: TextView
    private lateinit var btnFilter: Button
    private lateinit var filterSpinner: Spinner

    private val frameProcessor = FrameProcessor()
    private val uiHandler = Handler(Looper.getMainLooper())
    private var filterEnabled = false
    private var currentFilter = FilterType.GRAYSCALE_SHARPEN
    private var processing = false

    private val pickVideoLauncher =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
            uri?.let {
                contentResolver.takePersistableUriPermission(
                    it, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
                player.setMediaItem(MediaItem.fromUri(it))
                player.prepare()
                player.play()
            }
        }

    // Continuously grabs the current video frame and runs it through the
    // multi-threaded CPU filter, looping at roughly 25 fps.
    private val frameLoop = object : Runnable {
        override fun run() {
            if (filterEnabled && !processing) {
                val bmp = textureView.bitmap
                if (bmp != null) {
                    processing = true
                    Thread {
                        val result = frameProcessor.process(bmp, currentFilter)
                        uiHandler.post {
                            overlayImage.setImageBitmap(result)
                            processing = false
                        }
                    }.start()
                }
            }
            uiHandler.postDelayed(this, 40)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        textureView = findViewById(R.id.textureView)
        overlayImage = findViewById(R.id.overlayImage)
        statusText = findViewById(R.id.statusText)
        btnFilter = findViewById(R.id.btnFilter)
        filterSpinner = findViewById(R.id.filterSpinner)

        player = ExoPlayer.Builder(this).build()
        player.setVideoTextureView(textureView)

        val filters = arrayOf("Grayscale + Sharpen", "Sobel Edge Detect", "Heavy Stress (max CPU)")
        filterSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, filters)

        statusText.text = "CPU cores: ${frameProcessor.coreCountUsed()} | Filter: OFF"

        findViewById<Button>(R.id.btnPick).setOnClickListener {
            pickVideoLauncher.launch(arrayOf("video/*"))
        }

        findViewById<Button>(R.id.btnPlayPause).setOnClickListener {
            if (player.isPlaying) player.pause() else player.play()
        }

        btnFilter.setOnClickListener {
            filterEnabled = !filterEnabled
            btnFilter.text = if (filterEnabled) "CPU Filter: ON" else "CPU Filter: OFF"
            overlayImage.visibility = if (filterEnabled) View.VISIBLE else View.GONE
            statusText.text = "CPU cores: ${frameProcessor.coreCountUsed()} | Filter: ${if (filterEnabled) "ON" else "OFF"}"
        }

        filterSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                currentFilter = when (position) {
                    0 -> FilterType.GRAYSCALE_SHARPEN
                    1 -> FilterType.SOBEL_EDGE
                    else -> FilterType.HEAVY_STRESS
                }
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        uiHandler.post(frameLoop)
    }

    override fun onDestroy() {
        super.onDestroy()
        uiHandler.removeCallbacks(frameLoop)
        frameProcessor.shutdown()
        player.release()
    }
}
