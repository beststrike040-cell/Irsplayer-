package com.example.cpuvideoplayer

import android.graphics.Bitmap
import java.util.concurrent.Callable
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.math.sqrt

enum class FilterType {
    NONE, GRAYSCALE_SHARPEN, SOBEL_EDGE, HEAVY_STRESS
}

/**
 * Splits each video frame into horizontal strips and processes them in
 * parallel across every available CPU core. This does real per-pixel
 * convolution work on the CPU (no GPU shortcuts), so it genuinely
 * saturates all cores like a heavy video-processing workload.
 */
class FrameProcessor {

    private val coreCount = Runtime.getRuntime().availableProcessors()
    private val executor: ExecutorService = Executors.newFixedThreadPool(coreCount)

    fun coreCountUsed(): Int = coreCount

    fun process(source: Bitmap, filter: FilterType): Bitmap {
        if (filter == FilterType.NONE) return source

        val width = source.width
        val height = source.height
        val srcPixels = IntArray(width * height)
        source.getPixels(srcPixels, 0, width, 0, 0, width, height)
        val dstPixels = IntArray(width * height)

        val stripeHeight = (height / coreCount).coerceAtLeast(1)
        val tasks = mutableListOf<Callable<Unit>>()

        var y = 0
        while (y < height) {
            val startY = y
            val endY = (y + stripeHeight).coerceAtMost(height)
            tasks.add(Callable {
                processStripe(srcPixels, dstPixels, width, height, startY, endY, filter)
            })
            y += stripeHeight
        }

        // Blocks until every stripe (running on a separate core) finishes.
        executor.invokeAll(tasks)

        val output = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        output.setPixels(dstPixels, 0, width, 0, 0, width, height)
        return output
    }

    private fun processStripe(
        src: IntArray, dst: IntArray, width: Int, height: Int,
        startY: Int, endY: Int, filter: FilterType
    ) {
        when (filter) {
            FilterType.GRAYSCALE_SHARPEN -> grayscaleSharpen(src, dst, width, height, startY, endY)
            FilterType.SOBEL_EDGE -> sobelEdge(src, dst, width, height, startY, endY)
            FilterType.HEAVY_STRESS -> heavyStress(src, dst, width, height, startY, endY)
            else -> {}
        }
    }

    private fun clamp(v: Int) = v.coerceIn(0, 255)

    private fun grayscaleSharpen(
        src: IntArray, dst: IntArray, width: Int, height: Int, startY: Int, endY: Int
    ) {
        val kernel = arrayOf(
            intArrayOf(0, -1, 0),
            intArrayOf(-1, 5, -1),
            intArrayOf(0, -1, 0)
        )
        for (yy in startY until endY) {
            for (xx in 0 until width) {
                var sum = 0
                for (ky in -1..1) {
                    for (kx in -1..1) {
                        val sx = xx + kx
                        val sy = yy + ky
                        val px = if (sx in 0 until width && sy in 0 until height) src[sy * width + sx] else src[yy * width + xx]
                        val r = (px shr 16) and 0xFF
                        val g = (px shr 8) and 0xFF
                        val b = px and 0xFF
                        val gray = (r * 30 + g * 59 + b * 11) / 100
                        sum += gray * kernel[ky + 1][kx + 1]
                    }
                }
                val v = clamp(sum)
                dst[yy * width + xx] = (0xFF shl 24) or (v shl 16) or (v shl 8) or v
            }
        }
    }

    private fun sobelEdge(
        src: IntArray, dst: IntArray, width: Int, height: Int, startY: Int, endY: Int
    ) {
        val gx = arrayOf(intArrayOf(-1, 0, 1), intArrayOf(-2, 0, 2), intArrayOf(-1, 0, 1))
        val gy = arrayOf(intArrayOf(-1, -2, -1), intArrayOf(0, 0, 0), intArrayOf(1, 2, 1))

        for (yy in startY until endY) {
            for (xx in 0 until width) {
                var sumX = 0
                var sumY = 0
                for (ky in -1..1) {
                    for (kx in -1..1) {
                        val sx = xx + kx
                        val sy = yy + ky
                        val px = if (sx in 0 until width && sy in 0 until height) src[sy * width + sx] else src[yy * width + xx]
                        val r = (px shr 16) and 0xFF
                        val g = (px shr 8) and 0xFF
                        val b = px and 0xFF
                        val gray = (r + g + b) / 3
                        sumX += gray * gx[ky + 1][kx + 1]
                        sumY += gray * gy[ky + 1][kx + 1]
                    }
                }
                val mag = clamp(sqrt((sumX * sumX + sumY * sumY).toDouble()).toInt())
                dst[yy * width + xx] = (0xFF shl 24) or (mag shl 16) or (mag shl 8) or mag
            }
        }
    }

    /** Repeated blur passes purely to keep every core maxed out -- a genuine CPU stress workload. */
    private fun heavyStress(
        src: IntArray, dst: IntArray, width: Int, height: Int, startY: Int, endY: Int
    ) {
        val rows = endY - startY
        if (rows <= 0) return
        var current = src.copyOfRange(startY * width, endY * width)

        repeat(4) {
            val next = IntArray(current.size)
            for (yy in 0 until rows) {
                for (xx in 0 until width) {
                    var r = 0; var g = 0; var b = 0; var count = 0
                    for (ky in -1..1) {
                        for (kx in -1..1) {
                            val sx = xx + kx
                            val sy = yy + ky
                            if (sx in 0 until width && sy in 0 until rows) {
                                val px = current[sy * width + sx]
                                r += (px shr 16) and 0xFF
                                g += (px shr 8) and 0xFF
                                b += px and 0xFF
                                count++
                            }
                        }
                    }
                    val rr = r / count; val gg = g / count; val bb = b / count
                    next[yy * width + xx] = (0xFF shl 24) or (rr shl 16) or (gg shl 8) or bb
                }
            }
            current = next
        }

        for (i in current.indices) {
            dst[(startY + i / width) * width + (i % width)] = current[i]
        }
    }

    fun shutdown() {
        executor.shutdown()
    }
}
