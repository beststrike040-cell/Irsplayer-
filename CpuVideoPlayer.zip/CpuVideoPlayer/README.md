# CPU Video Player (Android)

## Idhu enna app?
Video play pannum boru, real-time-a CPU-la heavy filters apply pannum:
- **Grayscale + Sharpen** - convolution filter
- **Sobel Edge Detect** - edge-detection convolution
- **Heavy Stress (max CPU)** - repeated blur passes, ella cores-um max-a use aagum

Ovvoru frame-um horizontal stripes-a split panni, phone-la irukura ella CPU cores-layum (`Runtime.getRuntime().availableProcessors()`) parallel-a process pannum. So "Heavy Stress" mode-la CPU usage clear-a spike aaguradhu Android's Settings > Battery/Performance monitor-la paakalam.

## Build panra maadhiri - Option A: Computer + Android Studio irundha
1. Android Studio open pannunga (Hedgehog/Koala version, latest recommended).
2. **File > Open** → intha `CpuVideoPlayer` folder-a select pannunga.
3. Gradle sync automatic-a aagum (internet venum, dependencies download aagum). Sync mudinja aprom "Gradle wrapper illa" nu ketta, Android Studio automatic-a wrapper create pannikkum — accept pannunga.
4. Run button (▶) click pannunga, physical phone (USB debugging ON pannirukanum) illa emulator select pannunga.
5. App run aagum. **Build > Generate Signed Bundle / APK** vachi real `.apk` file generate pannikalam, adha phone-la direct install pannikalam.

## Build panra maadhiri - Option B: Mobile mattum irundha (computer illama)
GitHub Actions (free cloud build) use panni, phone browser-lendhe APK build pannikalam:

1. **github.com**-la free account create pannunga (phone browser-la).
2. Puthusa oru **repository** create pannunga (public or private, edhuvum sari) - peru edhavadhu vechikalam, e.g. `cpu-video-player`.
3. Intha zip-la irukura ella files/folders-um (`.github` folder including) andha repo-la upload pannunga:
   - Repo page-la "Add file" > "Upload files" click pannunga.
   - Zip-a first unga phone-la extract pannunga (File manager app use panni, "Extract" option irukum), appuram ellame select panni upload pannunga. `.github/workflows/build.yml` file kandippa upload aganum (idhu than build panra logic).
4. Upload aana udane, repo-la mele **"Actions"** tab-ku pogunga. "Build APK" workflow automatic-a run aagi irukum (2-5 nimisham aagum).
5. Workflow green tick aanathum, adha click pannunga → keezha **"Artifacts"** section-la `app-debug-apk` nu oru zip file irukum - adha download pannunga.
6. Andha zip-a extract panna, `app-debug.apk` kidaikum - idhai unga phone-la direct install pannikalam (Settings-la "Install unknown apps" permission kudukkanum first time).

Idhu completely free, GitHub cloud server-la than build aagum - unga phone-la edhuvum heavy processing nadakathu.

## Use panra maadhiri
1. "Pick Video" button click panni, phone-la irukura edhavadhu video file select pannunga.
2. Video automatic-a play aagum.
3. "CPU Filter" button ON pannunga, spinner-la filter type select pannunga.
4. "Heavy Stress" mode select pannina, CPU full-a load aagurathu clear-a therium (phone konjam soodagavum start aagalam — idhu expected).

## Minimum requirements
- Android 7.0 (API 24) or above
- minSdk 24, targetSdk/compileSdk 34
